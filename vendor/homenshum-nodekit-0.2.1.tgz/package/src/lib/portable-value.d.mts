export type PortableValue = null | boolean | number | string | PortableValue[] | { [key: string]: PortableValue };

export interface NormalizedStageDefinition {
  id: string;
  label: string;
  owner: string;
  status: "active" | "pending";
}

export function normalizePortableValue(value: unknown, label?: string): PortableValue;
export function normalizeStageDefinitions(stages: unknown): NormalizedStageDefinition[];
export function stageDefinitionsMatch(currentStages: unknown, requestedStages: NormalizedStageDefinition[]): boolean;
export function requireTrimmedText(value: unknown, label: string): string;
